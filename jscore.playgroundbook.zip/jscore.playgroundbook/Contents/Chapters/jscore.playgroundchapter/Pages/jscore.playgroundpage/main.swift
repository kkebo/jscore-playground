import PlaygroundSupport

PlaygroundPage.current.setLiveView(ConsoleView())
