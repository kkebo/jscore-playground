import PlaygroundSupport

PlaygroundPage.current.setLiveView(ConsoleView(viewModel: ConsoleViewModel()))
